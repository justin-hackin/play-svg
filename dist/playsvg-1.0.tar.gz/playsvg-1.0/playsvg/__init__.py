__all__ = ["color", "document", "element", "geom", "gradient", "gradshape", "path", "pathshapes"]

